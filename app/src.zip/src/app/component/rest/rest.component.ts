import { Component, OnInit } from '@angular/core';
import { MyserviceService } from '../../service/myservice.service';
@Component({
  selector: 'app-rest',
  templateUrl: './rest.component.html',
  styleUrls: ['./rest.component.css']
})
export class RestComponent implements OnInit {

  list;
  notdonelist;
  constructor(private myServiceService: MyserviceService) { }

  ngOnInit() {
    list:null;
  }

  // gettodos(){

  //   this.myServiceService.gettingtodos().subscribe(
  //     data=>{
  //       this.list=JSON.parse(JSON.stringify(data));
  //       console.log(this.list);
  //     }
  //   )


  // }
  getnotdonetodos(){

    this.myServiceService.gettingtodos().subscribe(
      data=>{
        this.list=JSON.parse(JSON.stringify(data));
        // if(data2.completed=="false"){
        //   this.list.push(data2);
        console.log(this.list);  
      }
        
      
    )
    this.list.forEach(function (value) {
      // console.log(value);
      if(value.completed=="false"){
        this.notdonelist.push(value);
      }
      console.log(this.notdonelist);
    }); 


  }

}
