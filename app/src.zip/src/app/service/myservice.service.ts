import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

const URL='http://jsonplaceholder.typicode.com/todos';

const httpOptions={
  headers:new HttpHeaders({
    'Content-type':'application/json',
    'Access-Control-Allow-Origin': '*'
  })
};

@Injectable({
  providedIn: 'root'
})
export class MyserviceService {

  constructor(private http:HttpClient) {


   }

   gettingtodos(){

    return this.http.get(URL,httpOptions);
   }

}
